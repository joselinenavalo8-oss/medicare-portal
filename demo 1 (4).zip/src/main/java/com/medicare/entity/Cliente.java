package com.medicare.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cliente")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {
    
    @Id
    @Column(name = "cliente_id", length = 5)
    private String clienteId;
    
    @Column(name = "ruc", length = 30)
    private String ruc;
    
    @Column(name = "nombre", nullable = false, length = 150)
    private String nombre;
    
    @Column(name = "direccion", length = 255)
    private String direccion;
    
    @Column(name = "ciudad", length = 100)
    private String ciudad;
    
    @Column(name = "telefono", length = 50)
    private String telefono;
    
    @Column(name = "email", length = 100)
    private String email;
}
