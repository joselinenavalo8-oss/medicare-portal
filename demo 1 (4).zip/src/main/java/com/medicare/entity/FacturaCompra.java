package com.medicare.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "factura_compra")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacturaCompra {
    
    @Id
    @Column(name = "compra_id", length = 10)
    private String compraId;
    
    @Column(name = "numero", nullable = false, length = 50)
    private String numero;
    
    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;
    
    @Column(name = "proveedor_id", nullable = false, length = 5)
    private String proveedorId;
    
    @Column(name = "plazo_pago", length = 50)
    private String plazoPago;
    
    @Column(name = "total_itbm", precision = 12, scale = 2)
    private BigDecimal totalItbm;
    
    @Column(name = "total", precision = 12, scale = 2)
    private BigDecimal total;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "proveedor_id", insertable = false, updatable = false)
    private Proveedor proveedor;
    
    @OneToMany(mappedBy = "facturaCompra", cascade = CascadeType.ALL)
    private List<FacturaCompraItem> items;
}
