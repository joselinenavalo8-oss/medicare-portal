package com.medicare.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "factura_venta")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacturaVenta {
    
    @Id
    @Column(name = "factura_id", length = 10)
    private String facturaId;
    
    @Column(name = "numero", nullable = false, length = 50)
    private String numero;
    
    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;
    
    @Column(name = "tipo", length = 20)
    private String tipo;
    
    @Column(name = "ubicacion_empresa", length = 200)
    private String ubicacionEmpresa;
    
    @Column(name = "cliente_id", nullable = false, length = 5)
    private String clienteId;
    
    @Column(name = "total_itbm", precision = 12, scale = 2)
    private BigDecimal totalItbm;
    
    @Column(name = "total", precision = 12, scale = 2)
    private BigDecimal total;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", insertable = false, updatable = false)
    private Cliente cliente;
    
    @OneToMany(mappedBy = "facturaVenta", cascade = CascadeType.ALL)
    private List<FacturaVentaItem> items;
}
