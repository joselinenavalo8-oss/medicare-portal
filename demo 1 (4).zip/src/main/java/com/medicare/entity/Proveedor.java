package com.medicare.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "proveedor")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Proveedor {
    
    @Id
    @Column(name = "proveedor_id", length = 5)
    private String proveedorId;
    
    @Column(name = "ruc", length = 30)
    private String ruc;
    
    @Column(name = "nombre", nullable = false, length = 150)
    private String nombre;
    
    @Column(name = "contacto", length = 100)
    private String contacto;
    
    @Column(name = "telefono", length = 50)
    private String telefono;
    
    @Column(name = "direccion", length = 255)
    private String direccion;
}
