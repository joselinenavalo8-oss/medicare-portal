package com.medicare.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Entity
@Table(name = "producto")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
    
    @Id
    @Column(name = "producto_id", length = 10)
    private String productoId;
    
    @Column(name = "codigo", length = 50)
    private String codigo;
    
    @Column(name = "descripcion", nullable = false, length = 200)
    private String descripcion;
    
    @Column(name = "categoria_id", nullable = false, length = 5)
    private String categoriaId;
    
    @Column(name = "precio_costo", precision = 12, scale = 2)
    private BigDecimal precioCosto;
    
    @Column(name = "precio_venta", precision = 12, scale = 2)
    private BigDecimal precioVenta;
    
    @Column(name = "proveedor_preferido", length = 5)
    private String proveedorPreferido;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id", insertable = false, updatable = false)
    private Categoria categoria;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "proveedor_preferido", insertable = false, updatable = false)
    private Proveedor proveedor;
}
