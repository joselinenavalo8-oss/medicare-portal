package com.medicare.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PatientDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String dateOfBirth;
    private String gender;
    private String address;
    private String medicalId;
    
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;
}

@Data
class CreatePatientRequest {
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String dateOfBirth;
    private String gender;
    private String address;
    private String medicalId;
}

@Data
class PatientsResponse {
    private java.util.List<PatientDTO> patients;
    private long count;
    
    public PatientsResponse(java.util.List<PatientDTO> patients, long count) {
        this.patients = patients;
        this.count = count;
    }
}
