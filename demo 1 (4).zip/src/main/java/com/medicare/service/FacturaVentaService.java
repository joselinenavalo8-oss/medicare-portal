package com.medicare.service;

import com.medicare.entity.FacturaVenta;
import com.medicare.repository.FacturaVentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class FacturaVentaService {
    
    @Autowired
    private FacturaVentaRepository facturaVentaRepository;
    
    public List<FacturaVenta> getAllFacturasVenta() {
        return facturaVentaRepository.findAll();
    }
    
    public Optional<FacturaVenta> getFacturaVentaById(String id) {
        return facturaVentaRepository.findById(id);
    }
    
    public List<FacturaVenta> getFacturasByCliente(String clienteId) {
        return facturaVentaRepository.findByClienteId(clienteId);
    }
    
    public List<FacturaVenta> getFacturasByDateRange(LocalDate startDate, LocalDate endDate) {
        return facturaVentaRepository.findByFechaBetween(startDate, endDate);
    }
    
    public List<FacturaVenta> getFacturasByTipo(String tipo) {
        return facturaVentaRepository.findByTipo(tipo);
    }
    
    public FacturaVenta saveFacturaVenta(FacturaVenta facturaVenta) {
        return facturaVentaRepository.save(facturaVenta);
    }
    
    public void deleteFacturaVenta(String id) {
        facturaVentaRepository.deleteById(id);
    }
}
