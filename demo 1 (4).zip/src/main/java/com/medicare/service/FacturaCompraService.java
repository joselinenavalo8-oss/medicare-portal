package com.medicare.service;

import com.medicare.entity.FacturaCompra;
import com.medicare.repository.FacturaCompraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class FacturaCompraService {
    
    @Autowired
    private FacturaCompraRepository facturaCompraRepository;
    
    public List<FacturaCompra> getAllFacturasCompra() {
        return facturaCompraRepository.findAll();
    }
    
    public Optional<FacturaCompra> getFacturaCompraById(String id) {
        return facturaCompraRepository.findById(id);
    }
    
    public List<FacturaCompra> getFacturasByProveedor(String proveedorId) {
        return facturaCompraRepository.findByProveedorId(proveedorId);
    }
    
    public List<FacturaCompra> getFacturasByDateRange(LocalDate startDate, LocalDate endDate) {
        return facturaCompraRepository.findByFechaBetween(startDate, endDate);
    }
    
    public FacturaCompra saveFacturaCompra(FacturaCompra facturaCompra) {
        return facturaCompraRepository.save(facturaCompra);
    }
    
    public void deleteFacturaCompra(String id) {
        facturaCompraRepository.deleteById(id);
    }
}
