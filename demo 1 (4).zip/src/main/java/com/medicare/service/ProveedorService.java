package com.medicare.service;

import com.medicare.entity.Proveedor;
import com.medicare.repository.ProveedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProveedorService {
    
    @Autowired
    private ProveedorRepository proveedorRepository;
    
    public List<Proveedor> getAllProveedores() {
        return proveedorRepository.findAll();
    }
    
    public Optional<Proveedor> getProveedorById(String id) {
        return proveedorRepository.findById(id);
    }
    
    public Proveedor saveProveedor(Proveedor proveedor) {
        return proveedorRepository.save(proveedor);
    }
    
    public void deleteProveedor(String id) {
        proveedorRepository.deleteById(id);
    }
}
