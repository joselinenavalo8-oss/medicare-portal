package com.medicare.repository;

import com.medicare.entity.FacturaVentaItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FacturaVentaItemRepository extends JpaRepository<FacturaVentaItem, Integer> {
    List<FacturaVentaItem> findByFacturaId(String facturaId);
    List<FacturaVentaItem> findByProductoId(String productoId);
}
