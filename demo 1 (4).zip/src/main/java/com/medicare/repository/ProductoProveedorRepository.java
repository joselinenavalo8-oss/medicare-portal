package com.medicare.repository;

import com.medicare.entity.ProductoProveedor;
import com.medicare.entity.ProductoProveedorId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductoProveedorRepository extends JpaRepository<ProductoProveedor, ProductoProveedorId> {
    List<ProductoProveedor> findByIdProductoId(String productoId);
    List<ProductoProveedor> findByIdProveedorId(String proveedorId);
}
