package com.medicare.repository;

import com.medicare.entity.FacturaCompraItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FacturaCompraItemRepository extends JpaRepository<FacturaCompraItem, Integer> {
    List<FacturaCompraItem> findByCompraId(String compraId);
    List<FacturaCompraItem> findByProductoId(String productoId);
}
