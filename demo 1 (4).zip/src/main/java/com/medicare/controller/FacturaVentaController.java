package com.medicare.controller;

import com.medicare.entity.FacturaVenta;
import com.medicare.service.FacturaVentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/facturas-venta")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FacturaVentaController {
    
    @Autowired
    private FacturaVentaService facturaVentaService;
    
    @GetMapping
    public List<FacturaVenta> getAllFacturasVenta() {
        return facturaVentaService.getAllFacturasVenta();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<FacturaVenta> getFacturaVentaById(@PathVariable String id) {
        Optional<FacturaVenta> factura = facturaVentaService.getFacturaVentaById(id);
        return factura.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @GetMapping("/cliente/{clienteId}")
    public List<FacturaVenta> getFacturasByCliente(@PathVariable String clienteId) {
        return facturaVentaService.getFacturasByCliente(clienteId);
    }
    
    @GetMapping("/date-range")
    public List<FacturaVenta> getFacturasByDateRange(
            @RequestParam("startDate") LocalDate startDate,
            @RequestParam("endDate") LocalDate endDate) {
        return facturaVentaService.getFacturasByDateRange(startDate, endDate);
    }
    
    @GetMapping("/tipo/{tipo}")
    public List<FacturaVenta> getFacturasByTipo(@PathVariable String tipo) {
        return facturaVentaService.getFacturasByTipo(tipo);
    }
    
    @PostMapping
    public ResponseEntity<FacturaVenta> createFacturaVenta(@RequestBody FacturaVenta facturaVenta) {
        FacturaVenta saved = facturaVentaService.saveFacturaVenta(facturaVenta);
        return ResponseEntity.ok(saved);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<FacturaVenta> updateFacturaVenta(@PathVariable String id, @RequestBody FacturaVenta facturaVenta) {
        Optional<FacturaVenta> existing = facturaVentaService.getFacturaVentaById(id);
        if (existing.isPresent()) {
            facturaVenta.setFacturaId(id);
            FacturaVenta updated = facturaVentaService.saveFacturaVenta(facturaVenta);
            return ResponseEntity.ok(updated);
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFacturaVenta(@PathVariable String id) {
        facturaVentaService.deleteFacturaVenta(id);
        return ResponseEntity.ok().build();
    }
}
