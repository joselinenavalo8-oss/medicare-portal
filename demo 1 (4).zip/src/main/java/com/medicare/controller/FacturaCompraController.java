package com.medicare.controller;

import com.medicare.entity.FacturaCompra;
import com.medicare.service.FacturaCompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/facturas-compra")
@CrossOrigin(origins = "*", maxAge = 3600)
public class FacturaCompraController {
    
    @Autowired
    private FacturaCompraService facturaCompraService;
    
    @GetMapping
    public List<FacturaCompra> getAllFacturasCompra() {
        return facturaCompraService.getAllFacturasCompra();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<FacturaCompra> getFacturaCompraById(@PathVariable String id) {
        Optional<FacturaCompra> factura = facturaCompraService.getFacturaCompraById(id);
        return factura.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @GetMapping("/proveedor/{proveedorId}")
    public List<FacturaCompra> getFacturasByProveedor(@PathVariable String proveedorId) {
        return facturaCompraService.getFacturasByProveedor(proveedorId);
    }
    
    @GetMapping("/date-range")
    public List<FacturaCompra> getFacturasByDateRange(
            @RequestParam("startDate") LocalDate startDate,
            @RequestParam("endDate") LocalDate endDate) {
        return facturaCompraService.getFacturasByDateRange(startDate, endDate);
    }
    
    @PostMapping
    public ResponseEntity<FacturaCompra> createFacturaCompra(@RequestBody FacturaCompra facturaCompra) {
        FacturaCompra saved = facturaCompraService.saveFacturaCompra(facturaCompra);
        return ResponseEntity.ok(saved);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<FacturaCompra> updateFacturaCompra(@PathVariable String id, @RequestBody FacturaCompra facturaCompra) {
        Optional<FacturaCompra> existing = facturaCompraService.getFacturaCompraById(id);
        if (existing.isPresent()) {
            facturaCompra.setCompraId(id);
            FacturaCompra updated = facturaCompraService.saveFacturaCompra(facturaCompra);
            return ResponseEntity.ok(updated);
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFacturaCompra(@PathVariable String id) {
        facturaCompraService.deleteFacturaCompra(id);
        return ResponseEntity.ok().build();
    }
}
