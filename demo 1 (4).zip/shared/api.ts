/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Patient Types
 */
export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  medicalId: string;
  createdAt: string;
}

export interface CreatePatientRequest {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  medicalId: string;
}

export interface PatientsResponse {
  patients: Patient[];
  count: number;
}

/**
 * Appointment Types
 */
export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  patientName: string;
  doctorName: string;
  dateTime: string;
  reason: string;
  status: "scheduled" | "completed" | "cancelled";
  notes?: string;
  createdAt: string;
}

export interface CreateAppointmentRequest {
  patientId: string;
  doctorId: string;
  dateTime: string;
  reason: string;
  notes?: string;
}

export interface AppointmentsResponse {
  appointments: Appointment[];
  count: number;
}

/**
 * Doctor Types
 */
export interface Doctor {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  specialty: string;
  phone: string;
  licenseNumber: string;
  yearsOfExperience: number;
  createdAt: string;
}

export interface DoctorsResponse {
  doctors: Doctor[];
  count: number;
}

/**
 * Clinical History Types
 */
export interface ClinicalHistory {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  doctorName: string;
  createdAt: string;
}

export interface HistoryResponse {
  history: ClinicalHistory[];
  count: number;
}

/**
 * Quick Consultation Types
 */
export interface QuickConsultation {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  date: string;
  notes: string;
  status: "active" | "completed";
  createdAt: string;
}

export interface CreateQuickConsultationRequest {
  patientId: string;
  doctorId: string;
  notes: string;
}

export interface QuickConsultationsResponse {
  consultations: QuickConsultation[];
  count: number;
}
