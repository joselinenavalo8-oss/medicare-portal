import { useNavigate } from "react-router-dom";
import { ArrowLeft, User, Mail, Phone, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Profile() {
  const navigate = useNavigate();
  const userType = "doctor";

  const userData = {
    name: userType === "doctor" ? "Dr. Smith" : "Triage Officer",
    email: userType === "doctor" ? "doctor@hospital.com" : "triage@hospital.com",
    role: userType === "doctor" ? "Doctor" : "Triage Officer",
    department: "Emergency Medicine",
    phone: "+1 (555) 123-4567",
    address: "123 Medical Center Drive, Suite 100, Hospital City, ST 12345",
    joinDate: "January 2023",
    status: "Active",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-50 to-medical-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
              <p className="text-xs text-slate-500">View your profile information</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Card */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
          {/* Header Banner */}
          <div className="h-32 bg-gradient-to-r from-medical-600 to-medical-700"></div>

          {/* Profile Content */}
          <div className="px-8 pb-8">
            {/* Avatar Section */}
            <div className="flex flex-col md:flex-row md:items-start md:gap-6 -mt-16 mb-8">
              <div className="w-32 h-32 bg-gradient-to-br from-medical-600 to-medical-700 rounded-2xl flex items-center justify-center text-white shadow-lg border-4 border-white">
                <User className="w-16 h-16" />
              </div>
              <div className="flex-1 mt-4 md:mt-8">
                <h2 className="text-3xl font-bold text-slate-900">{userData.name}</h2>
                <p className="text-lg text-medical-600 font-semibold mt-1">{userData.role}</p>
                <p className="text-sm text-slate-500 mt-1">{userData.department}</p>
                <div className="mt-4">
                  <span className="inline-block bg-green-100 text-green-800 text-xs font-semibold px-3 py-1 rounded-full">
                    {userData.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Information Grid */}
            <div className="space-y-6">
              {/* Contact Information Section */}
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Contact Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Email */}
                  <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Mail className="w-5 h-5 text-medical-600 mt-1 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm text-slate-600 font-medium">Email</p>
                      <p className="text-slate-900 font-semibold break-all">{userData.email}</p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Phone className="w-5 h-5 text-medical-600 mt-1 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm text-slate-600 font-medium">Phone</p>
                      <p className="text-slate-900 font-semibold">{userData.phone}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Address Section */}
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Address</h3>
                <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <MapPin className="w-5 h-5 text-medical-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-slate-600 font-medium">Work Address</p>
                    <p className="text-slate-900 font-semibold">{userData.address}</p>
                  </div>
                </div>
              </div>

              {/* Member Since Section */}
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Account Information</h3>
                <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <Calendar className="w-5 h-5 text-medical-600 mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-slate-600 font-medium">Member Since</p>
                    <p className="text-slate-900 font-semibold">{userData.joinDate}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-8 pt-8 border-t border-slate-200">
              <Button
                onClick={() => navigate("/dashboard")}
                variant="outline"
                className="flex-1"
              >
                Back to Dashboard
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
