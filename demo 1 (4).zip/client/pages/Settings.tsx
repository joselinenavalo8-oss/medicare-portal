import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Bell,
  Lock,
  Eye,
  Palette,
  Save,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Settings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"account" | "notifications" | "display" | "privacy">("account");
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Account Settings State
  const [accountData, setAccountData] = useState({
    firstName: "John",
    lastName: "Smith",
    email: "doctor@hospital.com",
    phone: "+1 (555) 123-4567",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  // Notification Settings State
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    appointmentReminders: true,
    patientUpdates: true,
    systemNotifications: true,
    pushNotifications: false,
    weeklyReport: true,
  });

  // Display Settings State
  const [display, setDisplay] = useState({
    theme: "light",
    language: "en",
    dateFormat: "MM/DD/YYYY",
    timeFormat: "12h",
    itemsPerPage: "25",
  });

  // Privacy Settings State
  const [privacy, setPrivacy] = useState({
    profileVisibility: "private",
    shareAnalytics: false,
    allowDataCollection: false,
    twoFactorEnabled: false,
    sessionTimeout: "30",
  });

  const handleAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAccountData(prev => ({ ...prev, [name]: value }));
  };

  const handleNotificationChange = (key: string) => {
    setNotifications(prev => ({
      ...prev,
      [key]: !prev[key as keyof typeof notifications],
    }));
  };

  const handleDisplayChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setDisplay(prev => ({ ...prev, [name]: value }));
  };

  const handlePrivacyChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      setPrivacy(prev => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked,
      }));
    } else {
      setPrivacy(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSave = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const TabButton = ({ tab, label, icon: Icon }: { tab: typeof activeTab; label: string; icon: any }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center gap-2 px-4 py-3 rounded-lg font-medium transition-all ${
        activeTab === tab
          ? "bg-medical-600 text-white"
          : "text-slate-600 hover:bg-slate-100"
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-50 to-medical-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
              <p className="text-xs text-slate-500">Manage your account and preferences</p>
            </div>
          </div>
          {saveSuccess && (
            <div className="flex items-center gap-2 bg-green-50 text-green-700 px-4 py-2 rounded-lg">
              <Check className="w-4 h-4" />
              <span className="text-sm font-medium">Saved successfully</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Tabs */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-2 sticky top-24">
              <div className="space-y-2">
                <TabButton tab="account" label="Account" icon={Lock} />
                <TabButton tab="notifications" label="Notifications" icon={Bell} />
                <TabButton tab="display" label="Display" icon={Palette} />
                <TabButton tab="privacy" label="Privacy" icon={Eye} />
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
              {/* Account Settings */}
              {activeTab === "account" && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 mb-6">Account Settings</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        First Name
                      </label>
                      <Input
                        type="text"
                        name="firstName"
                        value={accountData.firstName}
                        onChange={handleAccountChange}
                        placeholder="First name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Last Name
                      </label>
                      <Input
                        type="text"
                        name="lastName"
                        value={accountData.lastName}
                        onChange={handleAccountChange}
                        placeholder="Last name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Email Address
                    </label>
                    <Input
                      type="email"
                      name="email"
                      value={accountData.email}
                      onChange={handleAccountChange}
                      placeholder="Email address"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Phone Number
                    </label>
                    <Input
                      type="tel"
                      name="phone"
                      value={accountData.phone}
                      onChange={handleAccountChange}
                      placeholder="Phone number"
                    />
                  </div>

                  <div className="border-t border-slate-200 pt-6">
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">Change Password</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          Current Password
                        </label>
                        <Input
                          type="password"
                          name="currentPassword"
                          value={accountData.currentPassword}
                          onChange={handleAccountChange}
                          placeholder="Enter current password"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          New Password
                        </label>
                        <Input
                          type="password"
                          name="newPassword"
                          value={accountData.newPassword}
                          onChange={handleAccountChange}
                          placeholder="Enter new password"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          Confirm Password
                        </label>
                        <Input
                          type="password"
                          name="confirmPassword"
                          value={accountData.confirmPassword}
                          onChange={handleAccountChange}
                          placeholder="Confirm new password"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-6 border-t border-slate-200">
                    <Button onClick={handleSave} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save Changes
                    </Button>
                    <Button variant="outline">Cancel</Button>
                  </div>
                </div>
              )}

              {/* Notification Settings */}
              {activeTab === "notifications" && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 mb-6">Notification Settings</h2>
                  </div>

                  <div className="space-y-4">
                    {[
                      { key: "emailAlerts", label: "Email Alerts", description: "Receive email notifications for important updates" },
                      { key: "appointmentReminders", label: "Appointment Reminders", description: "Get reminders for upcoming appointments" },
                      { key: "patientUpdates", label: "Patient Updates", description: "Notifications when patient information is updated" },
                      { key: "systemNotifications", label: "System Notifications", description: "Important system and security notifications" },
                      { key: "pushNotifications", label: "Push Notifications", description: "Browser push notifications for real-time updates" },
                      { key: "weeklyReport", label: "Weekly Report", description: "Receive weekly summary report via email" },
                    ].map(({ key, label, description }) => (
                      <div key={key} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
                        <div className="flex-1">
                          <p className="font-medium text-slate-900">{label}</p>
                          <p className="text-sm text-slate-600">{description}</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer ml-4">
                          <input
                            type="checkbox"
                            checked={notifications[key as keyof typeof notifications] as boolean}
                            onChange={() => handleNotificationChange(key)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-medical-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-medical-600"></div>
                        </label>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-3 pt-6 border-t border-slate-200">
                    <Button onClick={handleSave} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save Changes
                    </Button>
                    <Button variant="outline">Cancel</Button>
                  </div>
                </div>
              )}

              {/* Display Settings */}
              {activeTab === "display" && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 mb-6">Display Settings</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Theme
                      </label>
                      <select
                        name="theme"
                        value={display.theme}
                        onChange={handleDisplayChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="light">Light</option>
                        <option value="dark">Dark</option>
                        <option value="auto">Auto (System)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Language
                      </label>
                      <select
                        name="language"
                        value={display.language}
                        onChange={handleDisplayChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="en">English</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Date Format
                      </label>
                      <select
                        name="dateFormat"
                        value={display.dateFormat}
                        onChange={handleDisplayChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                        <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                        <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Time Format
                      </label>
                      <select
                        name="timeFormat"
                        value={display.timeFormat}
                        onChange={handleDisplayChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="12h">12 Hour (AM/PM)</option>
                        <option value="24h">24 Hour</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Items Per Page
                      </label>
                      <select
                        name="itemsPerPage"
                        value={display.itemsPerPage}
                        onChange={handleDisplayChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-6 border-t border-slate-200">
                    <Button onClick={handleSave} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save Changes
                    </Button>
                    <Button variant="outline">Cancel</Button>
                  </div>
                </div>
              )}

              {/* Privacy Settings */}
              {activeTab === "privacy" && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 mb-6">Privacy & Security Settings</h2>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Profile Visibility
                      </label>
                      <select
                        name="profileVisibility"
                        value={privacy.profileVisibility}
                        onChange={handlePrivacyChange}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-medical-600 focus:border-transparent"
                      >
                        <option value="private">Private</option>
                        <option value="internal">Internal (Hospital Only)</option>
                        <option value="public">Public</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Session Timeout (minutes)
                      </label>
                      <Input
                        type="number"
                        name="sessionTimeout"
                        value={privacy.sessionTimeout}
                        onChange={handlePrivacyChange}
                        placeholder="Session timeout in minutes"
                      />
                    </div>
                  </div>

                  <div className="border-t border-slate-200 pt-6">
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">Data & Privacy</h3>

                    <div className="space-y-4">
                      {[
                        { key: "shareAnalytics", label: "Share Analytics", description: "Help us improve by sharing anonymous usage data" },
                        { key: "allowDataCollection", label: "Data Collection", description: "Allow collection of diagnostic data for support" },
                        { key: "twoFactorEnabled", label: "Two-Factor Authentication", description: "Require 2FA for account access" },
                      ].map(({ key, label, description }) => (
                        <div key={key} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
                          <div className="flex-1">
                            <p className="font-medium text-slate-900">{label}</p>
                            <p className="text-sm text-slate-600">{description}</p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer ml-4">
                            <input
                              type="checkbox"
                              name={key}
                              checked={privacy[key as keyof typeof privacy] as boolean}
                              onChange={handlePrivacyChange}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-medical-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-medical-600"></div>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-6 border-t border-slate-200">
                    <Button onClick={handleSave} className="gap-2">
                      <Save className="w-4 h-4" />
                      Save Changes
                    </Button>
                    <Button variant="outline">Cancel</Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
